"""Skincare Routine Manager — Streamlit web application."""

from __future__ import annotations

from datetime import date
from pathlib import Path

import streamlit as st

from src.enums import Category, SkinConcern, UsageTime
from src.exceptions import SkincareAppError
from src.models import Product
from src.product_manager import ProductManager

# ---------------------------------------------------------------------------
# Page configuration
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Skincare Routine Manager",
    page_icon="🧴",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Session-state initialisation
# ---------------------------------------------------------------------------
DATA_PATH = Path("data/products.json")

if "manager" not in st.session_state:
    st.session_state.manager = ProductManager(DATA_PATH)

if "edit_id" not in st.session_state:
    st.session_state.edit_id = None

if "delete_confirm_id" not in st.session_state:
    st.session_state.delete_confirm_id = None

manager: ProductManager = st.session_state.manager

# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

CATEGORY_OPTIONS = [c.value for c in Category]
USAGE_OPTIONS = [u.value for u in UsageTime]
CONCERN_OPTIONS = [s.value for s in SkinConcern]


def _expiry_badge(product: Product) -> str:
    """Return an expiry warning string if the product has expired."""
    if product.expiry_date and product.expiry_date < date.today():
        return f" ⚠️ Expired {product.expiry_date.strftime('%d %b %Y')}"
    if product.expiry_date:
        return f" · Expires {product.expiry_date.strftime('%d %b %Y')}"
    return ""


def _active_badge(product: Product) -> str:
    return "✅ In Use" if product.is_active else "⏸ Not in Use"


# ---------------------------------------------------------------------------
# Sidebar — global filters
# ---------------------------------------------------------------------------
with st.sidebar:
    st.title("🧴 Skincare Manager")
    st.markdown("---")
    st.subheader("Filter Products")

    filter_category = st.selectbox(
        "Category", ["All"] + CATEGORY_OPTIONS, key="filter_category"
    )
    filter_usage = st.selectbox(
        "Usage Time", ["All"] + USAGE_OPTIONS, key="filter_usage"
    )
    filter_concern = st.selectbox(
        "Skin Concern", ["All"] + CONCERN_OPTIONS, key="filter_concern"
    )
    filter_status = st.radio(
        "Usage Status",
        ["All", "In Use", "Not in Use"],
        key="filter_status",
        horizontal=True,
    )

    st.markdown("---")
    total = len(manager.get_all_products())
    active = len([p for p in manager.get_all_products() if p.is_active])
    st.metric("Total Products", total)
    st.metric("Currently In Use", active)

# ---------------------------------------------------------------------------
# Main tabs
# ---------------------------------------------------------------------------
tab_list, tab_add, tab_edit = st.tabs(["📋 My Products", "➕ Add Product", "✏️ Edit Product"])

# ===========================================================================
# TAB: My Products
# ===========================================================================
with tab_list:
    st.header("My Skincare Products")

    # Build filter kwargs
    fkw: dict = {}
    if filter_category != "All":
        fkw["category"] = filter_category
    if filter_usage != "All":
        fkw["usage_time"] = filter_usage
    if filter_concern != "All":
        fkw["skin_concern"] = filter_concern
    if filter_status == "In Use":
        fkw["is_active"] = True
    elif filter_status == "Not in Use":
        fkw["is_active"] = False

    products = manager.filter_products(**fkw)

    if not manager.get_all_products():
        st.info("No products added yet. Use the **➕ Add Product** tab to get started.")
    elif not products:
        st.warning("No products match the current filters. Try adjusting the sidebar filters.")
    else:
        for product in products:
            expiry_text = _expiry_badge(product)
            is_expired = product.expiry_date is not None and product.expiry_date < date.today()

            with st.expander(
                f"{'🔴' if is_expired else ('🟢' if product.is_active else '🔘')}  "
                f"**{product.name}** — {product.category.value}{expiry_text}",
                expanded=False,
            ):
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown(f"**Category:** {product.category.value}")
                    st.markdown(f"**Usage Time:** {product.usage_time.value}")
                    st.markdown(f"**Skin Concern:** {product.skin_concern.value}")
                with col2:
                    st.markdown(f"**Status:** {_active_badge(product)}")
                    if product.expiry_date:
                        label = (
                            f"⚠️ Expired: {product.expiry_date.strftime('%d %b %Y')}"
                            if is_expired
                            else f"Expires: {product.expiry_date.strftime('%d %b %Y')}"
                        )
                        st.markdown(f"**Expiry Date:** {label}")
                    else:
                        st.markdown("**Expiry Date:** Not set")
                    st.markdown(
                        f"**Added:** {product.created_at.strftime('%d %b %Y')}"
                    )

                if product.description:
                    st.markdown(f"*{product.description}*")

                btn_col1, btn_col2, btn_col3 = st.columns(3)

                with btn_col1:
                    toggle_label = "Mark Not in Use" if product.is_active else "Mark In Use"
                    if st.button(toggle_label, key=f"toggle_{product.id}"):
                        try:
                            manager.toggle_active(product.id)
                            st.rerun()
                        except SkincareAppError as e:
                            st.error(str(e))

                with btn_col2:
                    if st.button("✏️ Edit", key=f"edit_{product.id}"):
                        st.session_state.edit_id = product.id
                        st.session_state.delete_confirm_id = None
                        st.rerun()

                with btn_col3:
                    if st.session_state.delete_confirm_id == product.id:
                        st.warning("Are you sure?")
                        c1, c2 = st.columns(2)
                        with c1:
                            if st.button("Yes, delete", key=f"confirm_del_{product.id}"):
                                try:
                                    manager.delete_product(product.id)
                                    st.session_state.delete_confirm_id = None
                                    st.rerun()
                                except SkincareAppError as e:
                                    st.error(str(e))
                        with c2:
                            if st.button("Cancel", key=f"cancel_del_{product.id}"):
                                st.session_state.delete_confirm_id = None
                                st.rerun()
                    else:
                        if st.button("🗑️ Delete", key=f"delete_{product.id}"):
                            st.session_state.delete_confirm_id = product.id
                            st.rerun()

# ===========================================================================
# TAB: Add Product
# ===========================================================================
with tab_add:
    st.header("Add a New Product")

    with st.form("add_product_form", clear_on_submit=True):
        name = st.text_input("Product Name *", placeholder="e.g. CeraVe Hydrating Cleanser")
        description = st.text_area(
            "Description (optional)",
            placeholder="Notes about this product…",
            max_chars=300,
        )
        col1, col2, col3 = st.columns(3)
        with col1:
            category = st.selectbox("Category *", CATEGORY_OPTIONS)
        with col2:
            usage_time = st.selectbox("Usage Time *", USAGE_OPTIONS)
        with col3:
            skin_concern = st.selectbox("Skin Concern *", CONCERN_OPTIONS)

        use_expiry = st.checkbox("Set an expiry date")
        expiry_date: date | None = None
        if use_expiry:
            expiry_date = st.date_input("Expiry Date", min_value=date.today())

        is_active = st.checkbox("Currently in use", value=True)

        submitted = st.form_submit_button("➕ Add Product", type="primary")

    if submitted:
        try:
            product = manager.add_product(
                name=name,
                category=category,
                usage_time=usage_time,
                skin_concern=skin_concern,
                description=description,
                expiry_date=expiry_date if use_expiry else None,
                is_active=is_active,
            )
            st.success(f"✅ **{product.name}** added successfully!")
        except SkincareAppError as e:
            st.error(str(e))

# ===========================================================================
# TAB: Edit Product
# ===========================================================================
with tab_edit:
    st.header("Edit Product")

    if st.session_state.edit_id is None:
        st.info("Select a product to edit from the **📋 My Products** tab.")
    else:
        try:
            product = manager.get_product_by_id(st.session_state.edit_id)
        except SkincareAppError as e:
            st.error(str(e))
            st.session_state.edit_id = None
            st.stop()

        st.markdown(f"Editing: **{product.name}**")

        with st.form("edit_product_form"):
            e_name = st.text_input("Product Name *", value=product.name)
            e_description = st.text_area(
                "Description (optional)", value=product.description, max_chars=300
            )

            col1, col2, col3 = st.columns(3)
            with col1:
                e_category = st.selectbox(
                    "Category *",
                    CATEGORY_OPTIONS,
                    index=CATEGORY_OPTIONS.index(product.category.value),
                )
            with col2:
                e_usage = st.selectbox(
                    "Usage Time *",
                    USAGE_OPTIONS,
                    index=USAGE_OPTIONS.index(product.usage_time.value),
                )
            with col3:
                e_concern = st.selectbox(
                    "Skin Concern *",
                    CONCERN_OPTIONS,
                    index=CONCERN_OPTIONS.index(product.skin_concern.value),
                )

            e_use_expiry = st.checkbox(
                "Set an expiry date", value=product.expiry_date is not None
            )
            e_expiry: date | None = None
            if e_use_expiry:
                e_expiry = st.date_input(
                    "Expiry Date",
                    value=product.expiry_date or date.today(),
                    min_value=date.today(),
                )

            e_is_active = st.checkbox("Currently in use", value=product.is_active)

            save_col, cancel_col = st.columns(2)
            with save_col:
                save_clicked = st.form_submit_button("💾 Save Changes", type="primary")
            with cancel_col:
                cancel_clicked = st.form_submit_button("Cancel")

        if save_clicked:
            try:
                manager.update_product(
                    product_id=st.session_state.edit_id,
                    name=e_name,
                    category=e_category,
                    usage_time=e_usage,
                    skin_concern=e_concern,
                    description=e_description,
                    expiry_date=e_expiry if e_use_expiry else None,
                    clear_expiry=not e_use_expiry,
                    is_active=e_is_active,
                )
                st.success("✅ Product updated successfully!")
                st.session_state.edit_id = None
                st.rerun()
            except SkincareAppError as e:
                st.error(str(e))

        if cancel_clicked:
            st.session_state.edit_id = None
            st.rerun()
