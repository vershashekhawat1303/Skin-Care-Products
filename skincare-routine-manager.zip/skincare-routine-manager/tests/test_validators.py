"""Unit tests for src/validators.py"""

from __future__ import annotations

from datetime import date, timedelta

import pytest

from src.exceptions import DuplicateProductError, InvalidFieldError
from src.enums import Category, SkinConcern, UsageTime
from src.validators import (
    validate_description,
    validate_enum_field,
    validate_expiry_date,
    validate_name,
)

# ---------------------------------------------------------------------------
# validate_name
# ---------------------------------------------------------------------------

class TestValidateName:
    def test_valid_name_returns_stripped(self):
        assert validate_name("  CeraVe  ", []) == "CeraVe"

    def test_empty_string_raises(self):
        with pytest.raises(InvalidFieldError, match="empty"):
            validate_name("", [])

    def test_whitespace_only_raises(self):
        with pytest.raises(InvalidFieldError, match="empty"):
            validate_name("   ", [])

    def test_name_too_long_raises(self):
        long_name = "A" * 101
        with pytest.raises(InvalidFieldError, match="100 characters"):
            validate_name(long_name, [])

    def test_name_exactly_100_chars_is_valid(self):
        name = "A" * 100
        assert validate_name(name, []) == name

    def test_duplicate_name_raises(self):
        with pytest.raises(DuplicateProductError):
            validate_name("CeraVe", ["CeraVe"], existing_ids=["id-1"])

    def test_duplicate_name_case_insensitive(self):
        with pytest.raises(DuplicateProductError):
            validate_name("cerave", ["CeraVe"], existing_ids=["id-1"])

    def test_edit_excludes_self(self):
        # Same name is allowed when exclude_id matches the existing entry
        result = validate_name(
            "CeraVe",
            ["CeraVe"],
            exclude_id="id-1",
            existing_ids=["id-1"],
        )
        assert result == "CeraVe"

    def test_edit_still_catches_other_duplicate(self):
        # exclude_id only skips its own entry, not another product with the same name
        with pytest.raises(DuplicateProductError):
            validate_name(
                "CeraVe",
                ["CeraVe", "Neutrogena"],
                exclude_id="id-2",
                existing_ids=["id-1", "id-2"],
            )


# ---------------------------------------------------------------------------
# validate_description
# ---------------------------------------------------------------------------

class TestValidateDescription:
    def test_valid_description_returns_stripped(self):
        assert validate_description("  Great product  ") == "Great product"

    def test_empty_description_is_valid(self):
        assert validate_description("") == ""

    def test_description_too_long_raises(self):
        with pytest.raises(InvalidFieldError, match="300 characters"):
            validate_description("X" * 301)

    def test_description_exactly_300_chars_is_valid(self):
        desc = "X" * 300
        assert validate_description(desc) == desc


# ---------------------------------------------------------------------------
# validate_expiry_date
# ---------------------------------------------------------------------------

class TestValidateExpiryDate:
    def test_none_returns_none(self):
        assert validate_expiry_date(None) is None

    def test_today_is_valid(self):
        today = date.today()
        assert validate_expiry_date(today) == today

    def test_future_date_is_valid(self):
        future = date.today() + timedelta(days=30)
        assert validate_expiry_date(future) == future

    def test_past_date_raises(self):
        past = date.today() - timedelta(days=1)
        with pytest.raises(InvalidFieldError, match="past"):
            validate_expiry_date(past)


# ---------------------------------------------------------------------------
# validate_enum_field
# ---------------------------------------------------------------------------

class TestValidateEnumField:
    def test_valid_category_returns_enum(self):
        result = validate_enum_field("Cleanser", Category)
        assert result == Category.CLEANSER

    def test_valid_usage_time_returns_enum(self):
        result = validate_enum_field("Morning", UsageTime)
        assert result == UsageTime.MORNING

    def test_valid_skin_concern_returns_enum(self):
        result = validate_enum_field("Acne", SkinConcern)
        assert result == SkinConcern.ACNE

    def test_invalid_value_raises(self):
        with pytest.raises(InvalidFieldError, match="not a valid"):
            validate_enum_field("BadValue", Category)

    def test_empty_string_raises(self):
        with pytest.raises(InvalidFieldError):
            validate_enum_field("", UsageTime)
