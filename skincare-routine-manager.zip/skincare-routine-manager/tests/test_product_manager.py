"""Unit tests for src/product_manager.py"""

from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

import pytest

from src.enums import Category, SkinConcern, UsageTime
from src.exceptions import DuplicateProductError, InvalidFieldError, ProductNotFoundError
from src.product_manager import ProductManager


@pytest.fixture
def manager(tmp_path: Path) -> ProductManager:
    """Return a fresh ProductManager backed by a temp JSON file."""
    return ProductManager(tmp_path / "products.json")


# ---------------------------------------------------------------------------
# add_product
# ---------------------------------------------------------------------------

class TestAddProduct:
    def test_add_product_success(self, manager: ProductManager):
        p = manager.add_product(
            name="CeraVe Cleanser",
            category="Cleanser",
            usage_time="Morning",
            skin_concern="Dryness",
        )
        assert p.name == "CeraVe Cleanser"
        assert p.category == Category.CLEANSER
        assert p.usage_time == UsageTime.MORNING
        assert p.skin_concern == SkinConcern.DRYNESS
        assert p.is_active is True
        assert p.id  # has a UUID

    def test_add_product_persists(self, tmp_path: Path):
        path = tmp_path / "products.json"
        m1 = ProductManager(path)
        m1.add_product("Toner A", "Toner", "Evening", "Acne")
        m2 = ProductManager(path)
        assert len(m2.get_all_products()) == 1
        assert m2.get_all_products()[0].name == "Toner A"

    def test_add_product_with_optional_fields(self, manager: ProductManager):
        expiry = date.today() + timedelta(days=60)
        p = manager.add_product(
            name="Sunscreen X",
            category="Sunscreen",
            usage_time="Both",
            skin_concern="Anti-Aging",
            description="SPF 50",
            expiry_date=expiry,
            is_active=False,
        )
        assert p.description == "SPF 50"
        assert p.expiry_date == expiry
        assert p.is_active is False

    def test_add_duplicate_name_raises(self, manager: ProductManager):
        manager.add_product("Serum A", "Serum", "Morning", "Acne")
        with pytest.raises(DuplicateProductError):
            manager.add_product("Serum A", "Serum", "Evening", "Oiliness")

    def test_add_duplicate_name_case_insensitive(self, manager: ProductManager):
        manager.add_product("Serum A", "Serum", "Morning", "Acne")
        with pytest.raises(DuplicateProductError):
            manager.add_product("serum a", "Serum", "Evening", "Oiliness")

    def test_add_empty_name_raises(self, manager: ProductManager):
        with pytest.raises(InvalidFieldError):
            manager.add_product("", "Serum", "Morning", "Acne")

    def test_add_invalid_category_raises(self, manager: ProductManager):
        with pytest.raises(InvalidFieldError):
            manager.add_product("X", "NotACategory", "Morning", "Acne")

    def test_add_invalid_usage_time_raises(self, manager: ProductManager):
        with pytest.raises(InvalidFieldError):
            manager.add_product("X", "Serum", "Afternoon", "Acne")

    def test_add_invalid_skin_concern_raises(self, manager: ProductManager):
        with pytest.raises(InvalidFieldError):
            manager.add_product("X", "Serum", "Morning", "Wrinkles")

    def test_add_past_expiry_raises(self, manager: ProductManager):
        past = date.today() - timedelta(days=1)
        with pytest.raises(InvalidFieldError, match="past"):
            manager.add_product("X", "Serum", "Morning", "Acne", expiry_date=past)


# ---------------------------------------------------------------------------
# get_all_products / get_product_by_id
# ---------------------------------------------------------------------------

class TestGetProducts:
    def test_get_all_empty(self, manager: ProductManager):
        assert manager.get_all_products() == []

    def test_get_all_returns_all(self, manager: ProductManager):
        manager.add_product("A", "Serum", "Morning", "Acne")
        manager.add_product("B", "Toner", "Evening", "Dryness")
        assert len(manager.get_all_products()) == 2

    def test_get_by_id_success(self, manager: ProductManager):
        p = manager.add_product("A", "Serum", "Morning", "Acne")
        fetched = manager.get_product_by_id(p.id)
        assert fetched.id == p.id

    def test_get_by_id_not_found(self, manager: ProductManager):
        with pytest.raises(ProductNotFoundError):
            manager.get_product_by_id("nonexistent-id")


# ---------------------------------------------------------------------------
# update_product
# ---------------------------------------------------------------------------

class TestUpdateProduct:
    def test_update_name(self, manager: ProductManager):
        p = manager.add_product("Old Name", "Serum", "Morning", "Acne")
        updated = manager.update_product(p.id, name="New Name")
        assert updated.name == "New Name"

    def test_update_category(self, manager: ProductManager):
        p = manager.add_product("P", "Serum", "Morning", "Acne")
        updated = manager.update_product(p.id, category="Cleanser")
        assert updated.category == Category.CLEANSER

    def test_update_is_active(self, manager: ProductManager):
        p = manager.add_product("P", "Serum", "Morning", "Acne")
        updated = manager.update_product(p.id, is_active=False)
        assert updated.is_active is False

    def test_update_clear_expiry(self, manager: ProductManager):
        expiry = date.today() + timedelta(days=30)
        p = manager.add_product("P", "Serum", "Morning", "Acne", expiry_date=expiry)
        assert p.expiry_date is not None
        updated = manager.update_product(p.id, clear_expiry=True)
        assert updated.expiry_date is None

    def test_update_name_to_duplicate_raises(self, manager: ProductManager):
        manager.add_product("Alpha", "Serum", "Morning", "Acne")
        p2 = manager.add_product("Beta", "Toner", "Evening", "Dryness")
        with pytest.raises(DuplicateProductError):
            manager.update_product(p2.id, name="Alpha")

    def test_update_name_to_same_name_is_allowed(self, manager: ProductManager):
        p = manager.add_product("Alpha", "Serum", "Morning", "Acne")
        updated = manager.update_product(p.id, name="Alpha")
        assert updated.name == "Alpha"

    def test_update_not_found_raises(self, manager: ProductManager):
        with pytest.raises(ProductNotFoundError):
            manager.update_product("bad-id", name="X")


# ---------------------------------------------------------------------------
# delete_product
# ---------------------------------------------------------------------------

class TestDeleteProduct:
    def test_delete_success(self, manager: ProductManager):
        p = manager.add_product("A", "Serum", "Morning", "Acne")
        manager.delete_product(p.id)
        assert manager.get_all_products() == []

    def test_delete_not_found_raises(self, manager: ProductManager):
        with pytest.raises(ProductNotFoundError):
            manager.delete_product("ghost-id")

    def test_delete_persists(self, tmp_path: Path):
        path = tmp_path / "products.json"
        m1 = ProductManager(path)
        p = m1.add_product("A", "Serum", "Morning", "Acne")
        m1.delete_product(p.id)
        m2 = ProductManager(path)
        assert m2.get_all_products() == []


# ---------------------------------------------------------------------------
# toggle_active
# ---------------------------------------------------------------------------

class TestToggleActive:
    def test_toggle_active_to_inactive(self, manager: ProductManager):
        p = manager.add_product("P", "Serum", "Morning", "Acne")
        assert p.is_active is True
        toggled = manager.toggle_active(p.id)
        assert toggled.is_active is False

    def test_toggle_inactive_to_active(self, manager: ProductManager):
        p = manager.add_product("P", "Serum", "Morning", "Acne", is_active=False)
        toggled = manager.toggle_active(p.id)
        assert toggled.is_active is True

    def test_double_toggle_returns_original(self, manager: ProductManager):
        p = manager.add_product("P", "Serum", "Morning", "Acne")
        manager.toggle_active(p.id)
        toggled = manager.toggle_active(p.id)
        assert toggled.is_active is True

    def test_toggle_not_found_raises(self, manager: ProductManager):
        with pytest.raises(ProductNotFoundError):
            manager.toggle_active("no-such-id")


# ---------------------------------------------------------------------------
# filter_products
# ---------------------------------------------------------------------------

class TestFilterProducts:
    def _seed(self, manager: ProductManager):
        manager.add_product("Cleanser AM", "Cleanser", "Morning", "Oiliness")
        manager.add_product("Serum PM", "Serum", "Evening", "Acne", is_active=False)
        manager.add_product("Moisturizer Both", "Moisturizer", "Both", "Dryness")

    def test_no_filters_returns_all(self, manager: ProductManager):
        self._seed(manager)
        assert len(manager.filter_products()) == 3

    def test_filter_by_category(self, manager: ProductManager):
        self._seed(manager)
        results = manager.filter_products(category="Serum")
        assert len(results) == 1
        assert results[0].name == "Serum PM"

    def test_filter_by_usage_time(self, manager: ProductManager):
        self._seed(manager)
        results = manager.filter_products(usage_time="Morning")
        assert len(results) == 1
        assert results[0].name == "Cleanser AM"

    def test_filter_by_skin_concern(self, manager: ProductManager):
        self._seed(manager)
        results = manager.filter_products(skin_concern="Dryness")
        assert len(results) == 1
        assert results[0].name == "Moisturizer Both"

    def test_filter_by_is_active_true(self, manager: ProductManager):
        self._seed(manager)
        results = manager.filter_products(is_active=True)
        assert all(p.is_active for p in results)
        assert len(results) == 2

    def test_filter_by_is_active_false(self, manager: ProductManager):
        self._seed(manager)
        results = manager.filter_products(is_active=False)
        assert len(results) == 1
        assert results[0].name == "Serum PM"

    def test_filter_combined_and_logic(self, manager: ProductManager):
        self._seed(manager)
        results = manager.filter_products(category="Cleanser", is_active=True)
        assert len(results) == 1

    def test_filter_no_matches_returns_empty(self, manager: ProductManager):
        self._seed(manager)
        results = manager.filter_products(category="Sunscreen")
        assert results == []

    def test_filter_empty_store(self, manager: ProductManager):
        assert manager.filter_products(category="Serum") == []
