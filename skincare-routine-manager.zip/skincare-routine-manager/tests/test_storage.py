"""Unit tests for src/storage.py"""

from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path

import pytest

from src.enums import Category, SkinConcern, UsageTime
from src.models import Product
from src import storage


def _make_product(**kwargs) -> Product:
    defaults = dict(
        name="Test Product",
        category=Category.SERUM,
        usage_time=UsageTime.MORNING,
        skin_concern=SkinConcern.ACNE,
    )
    defaults.update(kwargs)
    return Product(**defaults)


class TestLoadProducts:
    def test_missing_file_returns_empty_list(self, tmp_path: Path):
        path = tmp_path / "nonexistent.json"
        assert storage.load_products(path) == []

    def test_corrupt_json_returns_empty_list(self, tmp_path: Path):
        path = tmp_path / "bad.json"
        path.write_text("not valid json", encoding="utf-8")
        assert storage.load_products(path) == []

    def test_empty_array_returns_empty_list(self, tmp_path: Path):
        path = tmp_path / "empty.json"
        path.write_text("[]", encoding="utf-8")
        assert storage.load_products(path) == []


class TestSaveAndLoad:
    def test_roundtrip_basic_product(self, tmp_path: Path):
        path = tmp_path / "products.json"
        p = _make_product()
        storage.save_products([p], path)
        loaded = storage.load_products(path)

        assert len(loaded) == 1
        lp = loaded[0]
        assert lp.id == p.id
        assert lp.name == p.name
        assert lp.category == p.category
        assert lp.usage_time == p.usage_time
        assert lp.skin_concern == p.skin_concern
        assert lp.description == p.description
        assert lp.is_active == p.is_active
        assert lp.expiry_date == p.expiry_date

    def test_roundtrip_with_expiry_date(self, tmp_path: Path):
        path = tmp_path / "products.json"
        expiry = date(2099, 12, 31)
        p = _make_product(expiry_date=expiry)
        storage.save_products([p], path)
        loaded = storage.load_products(path)
        assert loaded[0].expiry_date == expiry

    def test_roundtrip_none_expiry(self, tmp_path: Path):
        path = tmp_path / "products.json"
        p = _make_product(expiry_date=None)
        storage.save_products([p], path)
        loaded = storage.load_products(path)
        assert loaded[0].expiry_date is None

    def test_roundtrip_multiple_products(self, tmp_path: Path):
        path = tmp_path / "products.json"
        products = [
            _make_product(name="Alpha"),
            _make_product(name="Beta", category=Category.CLEANSER),
        ]
        storage.save_products(products, path)
        loaded = storage.load_products(path)
        assert len(loaded) == 2
        assert {p.name for p in loaded} == {"Alpha", "Beta"}

    def test_creates_parent_directory(self, tmp_path: Path):
        path = tmp_path / "nested" / "dir" / "products.json"
        storage.save_products([], path)
        assert path.exists()

    def test_overwrite_replaces_contents(self, tmp_path: Path):
        path = tmp_path / "products.json"
        storage.save_products([_make_product(name="First")], path)
        storage.save_products([_make_product(name="Second")], path)
        loaded = storage.load_products(path)
        assert len(loaded) == 1
        assert loaded[0].name == "Second"
