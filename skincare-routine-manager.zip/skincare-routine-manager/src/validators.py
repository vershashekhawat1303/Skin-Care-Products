"""Pure input validation functions for the Skincare Routine Manager."""

from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Optional, Type

from src.exceptions import DuplicateProductError, InvalidFieldError


def validate_name(
    name: str,
    existing_names: list[str],
    exclude_id: Optional[str] = None,
    existing_ids: Optional[list[str]] = None,
) -> str:
    """Validate and return a stripped product name.

    Args:
        name: The raw name input.
        existing_names: List of (name, id) tuples already in the store.
        exclude_id: Product ID to skip during uniqueness check (edit use case).
        existing_ids: List of IDs parallel to ``existing_names``.

    Returns:
        The stripped, valid name.

    Raises:
        InvalidFieldError: If the name is empty or exceeds 100 characters.
        DuplicateProductError: If the lowercased name already exists.
    """
    stripped = name.strip()
    if not stripped:
        raise InvalidFieldError("Product name cannot be empty.")
    if len(stripped) > 100:
        raise InvalidFieldError("Product name must be 100 characters or fewer.")

    lower = stripped.lower()
    for i, existing in enumerate(existing_names):
        if existing.lower() == lower:
            existing_id = existing_ids[i] if existing_ids else None
            if exclude_id is None or existing_id != exclude_id:
                raise DuplicateProductError(
                    f"A product named '{stripped}' already exists."
                )
    return stripped


def validate_description(description: str) -> str:
    """Validate and return a stripped description.

    Args:
        description: The raw description input.

    Returns:
        The stripped description.

    Raises:
        InvalidFieldError: If the description exceeds 300 characters.
    """
    stripped = description.strip()
    if len(stripped) > 300:
        raise InvalidFieldError("Description must be 300 characters or fewer.")
    return stripped


def validate_expiry_date(expiry_date: Optional[date]) -> Optional[date]:
    """Validate an optional expiry date.

    Args:
        expiry_date: A date object or None.

    Returns:
        The date unchanged, or None.

    Raises:
        InvalidFieldError: If the date is strictly in the past.
    """
    if expiry_date is None:
        return None
    if expiry_date < date.today():
        raise InvalidFieldError("Expiry date cannot be in the past.")
    return expiry_date


def validate_enum_field(value: str, enum_class: Type[Enum]) -> Enum:
    """Validate that a value is a member of the given enum.

    Args:
        value: The raw string value.
        enum_class: The enum class to validate against.

    Returns:
        The matching enum member.

    Raises:
        InvalidFieldError: If the value is not a valid enum member.
    """
    try:
        return enum_class(value)
    except ValueError:
        allowed = ", ".join(e.value for e in enum_class)
        raise InvalidFieldError(
            f"'{value}' is not a valid {enum_class.__name__}. "
            f"Allowed values: {allowed}."
        )
