"""Custom exceptions for the Skincare Routine Manager."""


class SkincareAppError(Exception):
    """Base exception for all application errors."""


class DuplicateProductError(SkincareAppError):
    """Raised when a product with the same name already exists."""


class ProductNotFoundError(SkincareAppError):
    """Raised when a product ID cannot be found in the store."""


class InvalidFieldError(SkincareAppError):
    """Raised when a field value fails validation."""
