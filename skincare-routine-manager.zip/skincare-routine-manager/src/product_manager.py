"""Business logic layer for the Skincare Routine Manager."""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Optional

from src.enums import Category, SkinConcern, UsageTime
from src.exceptions import ProductNotFoundError
from src.models import Product
from src import storage
from src.validators import (
    validate_description,
    validate_enum_field,
    validate_expiry_date,
    validate_name,
)


class ProductManager:
    """Manages the in-memory product collection and delegates to storage.

    All mutations are immediately persisted via the storage layer.
    Validation is performed before any mutation.
    """

    def __init__(self, storage_path: Path = storage.DEFAULT_PATH) -> None:
        """Initialise the manager and load persisted products.

        Args:
            storage_path: Path to the JSON file used for persistence.
        """
        self._path = storage_path
        self._products: list[Product] = storage.load_products(self._path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find(self, product_id: str) -> Product:
        """Return the product with the given ID or raise ProductNotFoundError."""
        for p in self._products:
            if p.id == product_id:
                return p
        raise ProductNotFoundError(f"No product found with ID '{product_id}'.")

    def _save(self) -> None:
        """Persist the current product list to disk."""
        storage.save_products(self._products, self._path)

    def _existing_names(self) -> list[str]:
        return [p.name for p in self._products]

    def _existing_ids(self) -> list[str]:
        return [p.id for p in self._products]

    # ------------------------------------------------------------------
    # Public CRUD methods
    # ------------------------------------------------------------------

    def add_product(
        self,
        name: str,
        category: str,
        usage_time: str,
        skin_concern: str,
        description: str = "",
        expiry_date: Optional[date] = None,
        is_active: bool = True,
    ) -> Product:
        """Validate inputs, create a new product, persist and return it.

        Args:
            name: Product name (required, unique).
            category: One of the Category enum values.
            usage_time: One of the UsageTime enum values.
            skin_concern: One of the SkinConcern enum values.
            description: Optional free-text description.
            expiry_date: Optional expiry date (must not be in the past).
            is_active: Whether the product is currently in use.

        Returns:
            The newly created Product.

        Raises:
            InvalidFieldError: On any validation failure.
            DuplicateProductError: If the name is already taken.
        """
        clean_name = validate_name(name, self._existing_names(), existing_ids=self._existing_ids())
        clean_desc = validate_description(description)
        clean_category = validate_enum_field(category, Category)
        clean_usage = validate_enum_field(usage_time, UsageTime)
        clean_concern = validate_enum_field(skin_concern, SkinConcern)
        clean_expiry = validate_expiry_date(expiry_date)

        product = Product(
            name=clean_name,
            description=clean_desc,
            category=clean_category,
            usage_time=clean_usage,
            skin_concern=clean_concern,
            expiry_date=clean_expiry,
            is_active=is_active,
        )
        self._products.append(product)
        self._save()
        return product

    def get_all_products(self) -> list[Product]:
        """Return a shallow copy of all products.

        Returns:
            List of all Product instances.
        """
        return list(self._products)

    def get_product_by_id(self, product_id: str) -> Product:
        """Return the product with the given ID.

        Args:
            product_id: UUID string of the product.

        Returns:
            The matching Product.

        Raises:
            ProductNotFoundError: If no product has that ID.
        """
        return self._find(product_id)

    def update_product(
        self,
        product_id: str,
        name: Optional[str] = None,
        category: Optional[str] = None,
        usage_time: Optional[str] = None,
        skin_concern: Optional[str] = None,
        description: Optional[str] = None,
        expiry_date: Optional[date] = None,
        clear_expiry: bool = False,
        is_active: Optional[bool] = None,
    ) -> Product:
        """Apply field changes to an existing product and persist.

        Only fields passed as non-None are updated. Pass ``clear_expiry=True``
        to explicitly remove the expiry date.

        Args:
            product_id: ID of the product to update.
            name: New name (uniqueness checked, excludes self).
            category: New category string.
            usage_time: New usage time string.
            skin_concern: New skin concern string.
            description: New description.
            expiry_date: New expiry date.
            clear_expiry: When True, sets expiry_date to None regardless of expiry_date param.
            is_active: New active status.

        Returns:
            The updated Product.

        Raises:
            ProductNotFoundError: If the ID is not found.
            InvalidFieldError / DuplicateProductError: On validation failure.
        """
        product = self._find(product_id)

        if name is not None:
            product.name = validate_name(
                name,
                self._existing_names(),
                exclude_id=product_id,
                existing_ids=self._existing_ids(),
            )
        if description is not None:
            product.description = validate_description(description)
        if category is not None:
            product.category = validate_enum_field(category, Category)
        if usage_time is not None:
            product.usage_time = validate_enum_field(usage_time, UsageTime)
        if skin_concern is not None:
            product.skin_concern = validate_enum_field(skin_concern, SkinConcern)
        if clear_expiry:
            product.expiry_date = None
        elif expiry_date is not None:
            product.expiry_date = validate_expiry_date(expiry_date)
        if is_active is not None:
            product.is_active = is_active

        self._save()
        return product

    def delete_product(self, product_id: str) -> None:
        """Remove a product from the store and persist.

        Args:
            product_id: ID of the product to delete.

        Raises:
            ProductNotFoundError: If the ID is not found.
        """
        product = self._find(product_id)
        self._products.remove(product)
        self._save()

    def toggle_active(self, product_id: str) -> Product:
        """Flip the is_active flag on a product and persist.

        Args:
            product_id: ID of the product to toggle.

        Returns:
            The updated Product.

        Raises:
            ProductNotFoundError: If the ID is not found.
        """
        product = self._find(product_id)
        product.is_active = not product.is_active
        self._save()
        return product

    # ------------------------------------------------------------------
    # Filtering
    # ------------------------------------------------------------------

    def filter_products(
        self,
        category: Optional[str] = None,
        usage_time: Optional[str] = None,
        skin_concern: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> list[Product]:
        """Return products matching all provided filter criteria (AND logic).

        Passing None for a parameter means "no filter on this field".

        Args:
            category: Filter by Category value string.
            usage_time: Filter by UsageTime value string.
            skin_concern: Filter by SkinConcern value string.
            is_active: Filter by active status.

        Returns:
            Filtered list of products.
        """
        results = list(self._products)
        if category is not None:
            results = [p for p in results if p.category.value == category]
        if usage_time is not None:
            results = [p for p in results if p.usage_time.value == usage_time]
        if skin_concern is not None:
            results = [p for p in results if p.skin_concern.value == skin_concern]
        if is_active is not None:
            results = [p for p in results if p.is_active == is_active]
        return results
