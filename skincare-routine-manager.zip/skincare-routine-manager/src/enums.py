"""Controlled vocabulary enums for the Skincare Routine Manager."""

from enum import Enum


class Category(str, Enum):
    CLEANSER = "Cleanser"
    TONER = "Toner"
    SERUM = "Serum"
    MOISTURIZER = "Moisturizer"
    SUNSCREEN = "Sunscreen"
    OTHER = "Other"


class UsageTime(str, Enum):
    MORNING = "Morning"
    EVENING = "Evening"
    BOTH = "Both"


class SkinConcern(str, Enum):
    ACNE = "Acne"
    DRYNESS = "Dryness"
    OILINESS = "Oiliness"
    DARK_SPOTS = "Dark Spots"
    ANTI_AGING = "Anti-Aging"
    GENERAL_CARE = "General Care"
