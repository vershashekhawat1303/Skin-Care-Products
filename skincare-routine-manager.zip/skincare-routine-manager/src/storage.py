"""JSON persistence helpers for the Skincare Routine Manager."""

from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path
from typing import Any

from src.enums import Category, SkinConcern, UsageTime
from src.models import Product

DEFAULT_PATH = Path("data/products.json")


def _product_to_dict(product: Product) -> dict[str, Any]:
    """Serialise a Product to a JSON-compatible dictionary."""
    return {
        "id": product.id,
        "name": product.name,
        "description": product.description,
        "category": product.category.value,
        "usage_time": product.usage_time.value,
        "skin_concern": product.skin_concern.value,
        "expiry_date": product.expiry_date.isoformat() if product.expiry_date else None,
        "is_active": product.is_active,
        "created_at": product.created_at.isoformat(),
    }


def _dict_to_product(data: dict[str, Any]) -> Product:
    """Deserialise a dictionary to a Product instance."""
    expiry_raw = data.get("expiry_date")
    expiry_date = date.fromisoformat(expiry_raw) if expiry_raw else None
    return Product(
        id=data["id"],
        name=data["name"],
        description=data.get("description", ""),
        category=Category(data["category"]),
        usage_time=UsageTime(data["usage_time"]),
        skin_concern=SkinConcern(data["skin_concern"]),
        expiry_date=expiry_date,
        is_active=data.get("is_active", True),
        created_at=datetime.fromisoformat(data["created_at"]),
    )


def save_products(products: list[Product], path: Path = DEFAULT_PATH) -> None:
    """Serialise the product list to a JSON file.

    Args:
        products: The list of products to persist.
        path: Destination file path (directory is created if absent).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = [_product_to_dict(p) for p in products]
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def load_products(path: Path = DEFAULT_PATH) -> list[Product]:
    """Load the product list from a JSON file.

    Returns an empty list if the file is absent or contains invalid JSON.

    Args:
        path: Source file path.

    Returns:
        A list of Product instances.
    """
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return [_dict_to_product(item) for item in raw]
    except (json.JSONDecodeError, KeyError, ValueError):
        return []
