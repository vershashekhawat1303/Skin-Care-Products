"""Product dataclass for the Skincare Routine Manager."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Optional

from src.enums import Category, SkinConcern, UsageTime


@dataclass
class Product:
    """Represents a single skincare product."""

    name: str
    category: Category
    usage_time: UsageTime
    skin_concern: SkinConcern
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    description: str = ""
    expiry_date: Optional[date] = None
    is_active: bool = True
    created_at: datetime = field(default_factory=datetime.now)
