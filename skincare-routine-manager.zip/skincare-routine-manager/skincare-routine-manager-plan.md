# Skincare Routine Manager — Implementation Plan

## Top-Level Overview

A single-user, browser-based skincare product tracker built with Python and Streamlit.
The user can add, edit, delete, and filter skincare products. Data is persisted to a local
JSON file so it survives browser refreshes. Business logic lives entirely outside Streamlit
in plain Python classes that are independently testable with pytest.

**Scope**
- CRUD operations on skincare products
- Filtering by category, usage time, skin concern, and active status
- Optional expiry date with past-date guard
- JSON file persistence (read on startup, write on every mutation)
- Full pytest unit-test coverage of all business logic

**Non-goals**
- Authentication, multi-user support
- External APIs, AI, databases
- Medical advice or diagnosis features

---

## Project Folder Structure

```
skincare-routine-manager/
├── app.py                    # Streamlit entry point
├── data/
│   └── products.json         # Persisted product data (auto-created)
├── src/
│   ├── __init__.py
│   ├── models.py             # Product dataclass
│   ├── enums.py              # Category, UsageTime, SkinConcern enums
│   ├── exceptions.py         # Custom exception classes
│   ├── validators.py         # Pure validation functions
│   ├── product_manager.py    # CRUD + filtering business logic
│   └── storage.py            # JSON read/write helpers
├── tests/
│   ├── __init__.py
│   ├── test_validators.py
│   ├── test_product_manager.py
│   └── test_storage.py
└── requirements.txt
```

---

## Sub-Tasks

---

### Sub-Task 1 — Project Scaffold

**Intent**
Establish the folder structure, dependencies file, and empty module stubs so every
subsequent sub-task has a predictable place to work.

**Expected Outcomes**
- All directories and `__init__.py` files exist
- `requirements.txt` lists `streamlit` and `pytest`
- Each source file exists (empty or with a module docstring only)
- Running `pytest` from the project root produces "no tests found" rather than an import error

**Todo List**
1. Create the directory tree: `src/`, `tests/`, `data/`
2. Add `__init__.py` to `src/` and `tests/`
3. Create empty stubs: `src/models.py`, `src/enums.py`, `src/exceptions.py`,
   `src/validators.py`, `src/product_manager.py`, `src/storage.py`, `app.py`
4. Write `requirements.txt` with `streamlit>=1.32.0` and `pytest>=8.0.0`

**Relevant Context**
- No existing codebase — pure greenfield
- Keep `data/products.json` absent at scaffold time; `storage.py` will create it on first write

**Status:** [ ] pending

---

### Sub-Task 2 — Enums and Data Model

**Intent**
Define the controlled vocabularies (enums) and the `Product` dataclass that is the
single source of truth for what a product looks like throughout the application.

**Expected Outcomes**
- `src/enums.py` contains `Category`, `UsageTime`, and `SkinConcern` string enums
- `src/models.py` contains a `Product` dataclass with all nine fields
- Importing both modules from a Python REPL works with no errors
- A `Product` can be created with only required fields; optional fields default correctly

**Todo List**
1. In `src/enums.py`, define `Category` enum: `Cleanser, Toner, Serum, Moisturizer, Sunscreen, Other`
2. In `src/enums.py`, define `UsageTime` enum: `Morning, Evening, Both`
3. In `src/enums.py`, define `SkinConcern` enum: `Acne, Dryness, Oiliness, DarkSpots, AntiAging, GeneralCare`
4. In `src/models.py`, define `Product` dataclass with fields:
   - `id: str` — UUID string, auto-generated via `field(default_factory=...)`
   - `name: str`
   - `description: str` — defaults to empty string
   - `category: Category`
   - `usage_time: UsageTime`
   - `skin_concern: SkinConcern`
   - `expiry_date: Optional[date]` — defaults to None
   - `is_active: bool` — defaults to True
   - `created_at: datetime` — auto-generated via `field(default_factory=...)`
5. Ensure `Product` is importable from `src.models`

**Relevant Context**
- Use `from enum import Enum` — string enums (`class Category(str, Enum)`) serialise
  cleanly to/from JSON without extra conversion
- `dataclasses.field(default_factory=...)` prevents mutable default issues

**Status:** [ ] pending

---

### Sub-Task 3 — Custom Exceptions

**Intent**
Define the three custom exceptions that the business logic layer raises so callers
(UI and tests) can handle errors precisely without catching broad `Exception`.

**Expected Outcomes**
- `src/exceptions.py` defines `DuplicateProductError`, `ProductNotFoundError`, `InvalidFieldError`
- All three inherit from a common base `SkincareAppError(Exception)`
- Each exception accepts a human-readable message string

**Todo List**
1. Define `SkincareAppError(Exception)` as the base class
2. Define `DuplicateProductError(SkincareAppError)`
3. Define `ProductNotFoundError(SkincareAppError)`
4. Define `InvalidFieldError(SkincareAppError)`

**Relevant Context**
- The UI will catch `SkincareAppError` broadly to display `st.error(str(e))`
- Tests will assert specific subclasses with `pytest.raises(DuplicateProductError)`

**Status:** [ ] pending

---

### Sub-Task 4 — Validators

**Intent**
Implement all input validation as pure functions with no Streamlit dependency.
Each function raises `InvalidFieldError` on failure, or returns cleanly on success.

**Expected Outcomes**
- `src/validators.py` contains four validator functions
- Each function is independently testable
- No Streamlit imports appear anywhere in `validators.py`

**Todo List**
1. `validate_name(name: str, existing_names: list[str], exclude_id: str | None = None) -> str`
   - Strip whitespace; raise `InvalidFieldError` if empty or longer than 100 chars
   - Raise `DuplicateProductError` if the lowercased name matches any name in `existing_names`
     (skip the product whose id matches `exclude_id` during edit)
   - Return the stripped name on success
2. `validate_description(description: str) -> str`
   - Strip whitespace; raise `InvalidFieldError` if longer than 300 chars
   - Return stripped value on success
3. `validate_expiry_date(expiry_date: date | None) -> date | None`
   - If None, return None immediately
   - Raise `InvalidFieldError` if the date is strictly before today
   - Return the date on success
4. `validate_enum_field(value, enum_class) -> Enum`
   - Raise `InvalidFieldError` if value is not a valid member of `enum_class`
   - Return the enum member on success

**Relevant Context**
- `existing_names` is produced by `ProductManager` before calling validators
- The `exclude_id` parameter is essential for the edit-product use case (EC-04 from analysis)

**Status:** [ ] pending

---

### Sub-Task 5 — Storage Layer

**Intent**
Implement load/save helpers that serialise the product list to and from a JSON file.
The rest of the application never directly touches the file system.

**Expected Outcomes**
- `src/storage.py` exposes `load_products(path) -> list[Product]` and `save_products(path, products)`
- If the file does not exist, `load_products` returns an empty list (no error)
- Round-tripping a list of products through save then load produces identical objects
- No Streamlit imports appear in `storage.py`

**Todo List**
1. Define `DEFAULT_PATH = Path("data/products.json")` constant
2. Implement `save_products(products: list[Product], path: Path = DEFAULT_PATH) -> None`
   - Create the `data/` directory if absent
   - Serialise each `Product` to a dict; convert `date`/`datetime` to ISO strings,
     enum members to their string values
   - Write the JSON array to the file
3. Implement `load_products(path: Path = DEFAULT_PATH) -> list[Product]`
   - Return empty list if file does not exist
   - Parse JSON array; reconstruct `Product` dataclass instances, converting ISO strings
     back to `date`/`datetime`, string values back to enum members
4. Handle `JSONDecodeError` gracefully — return empty list and do not crash

**Relevant Context**
- `str(enum_member)` on a `str, Enum` returns `"ClassName.value"` — use `.value` explicitly
  when serialising, and use `EnumClass(value)` when deserialising
- Tests for storage should use `tmp_path` fixture from pytest to avoid touching the real data file

**Status:** [ ] pending

---

### Sub-Task 6 — ProductManager

**Intent**
Implement the central business-logic class that owns the in-memory product list, delegates
to validators, and calls the storage layer on every mutation. This class is the only thing
the Streamlit UI talks to for any data operation.

**Expected Outcomes**
- `src/product_manager.py` contains `ProductManager` class
- All seven public methods work correctly in isolation (tested without Streamlit)
- Every mutation immediately persists via `storage.save_products`
- Filtering with no filter arguments returns the full list

**Todo List**
1. `__init__(self, storage_path)` — load products from storage into `self._products: list[Product]`
2. `add_product(name, description, category, usage_time, skin_concern, expiry_date, is_active) -> Product`
   - Run all validators
   - Create a `Product` instance with a new UUID and current timestamp
   - Append to `self._products` and save
   - Return the new product
3. `get_all_products() -> list[Product]`
   - Return a shallow copy of `self._products`
4. `get_product_by_id(product_id: str) -> Product`
   - Raise `ProductNotFoundError` if not found
5. `update_product(product_id, **fields) -> Product`
   - Fetch the existing product (raises `ProductNotFoundError` if absent)
   - Re-run validation on any field provided in `fields`, passing `exclude_id=product_id`
     for name uniqueness
   - Apply changes, save, return updated product
6. `delete_product(product_id: str) -> None`
   - Raise `ProductNotFoundError` if not found
   - Remove from list and save
7. `toggle_active(product_id: str) -> Product`
   - Flip `is_active` on the product, save, return updated product
8. `filter_products(category, usage_time, skin_concern, is_active) -> list[Product]`
   - All filter parameters are optional (default None means "no filter on this field")
   - Apply AND logic across all provided filters
   - Return matching products

**Relevant Context**
- `ProductManager` should accept `storage_path` in its constructor so tests can inject a
  `tmp_path`-based path without touching `data/products.json`
- `self._products` is the single mutable list; all reads return copies or filtered views

**Status:** [ ] pending

---

### Sub-Task 7 — Streamlit UI

**Intent**
Build the browser-facing interface in `app.py`. The UI delegates all data operations to a
single `ProductManager` instance stored in `st.session_state`. No business logic, validation,
or file I/O lives in `app.py`.

**Expected Outcomes**
- Running `streamlit run app.py` launches without errors
- All CRUD operations are reachable from the UI
- Validation errors display as `st.error` messages without crashing the app
- Filters update the displayed list in real time
- Expired products are visually flagged in the product list

**Todo List**
1. **Initialise session state** — on first load, create `st.session_state.manager = ProductManager()`
2. **Page layout** — use `st.tabs` to create three tabs: `"My Products"`, `"Add Product"`, `"Edit Product"`
3. **Add Product tab**
   - `st.text_input` for name
   - `st.text_area` for description
   - `st.selectbox` for category (choices from `Category` enum)
   - `st.selectbox` for usage time (choices from `UsageTime` enum)
   - `st.selectbox` for skin concern (choices from `SkinConcern` enum)
   - `st.date_input` for expiry date, with a checkbox to enable/disable it
   - `st.checkbox` for "Currently in use" (defaults checked)
   - Submit button — call `manager.add_product(...)`, show `st.success` or `st.error`
4. **My Products tab**
   - Filter sidebar or expander: dropdowns for category, usage time, skin concern; radio for active status
   - Call `manager.filter_products(...)` with selected filters
   - Display products in `st.columns` cards or an `st.dataframe`
   - Each product row/card has an "Edit" button (sets `st.session_state.edit_id`) and a "Delete" button
   - If no products match filters, show `st.info("No products match your filters.")`
   - If no products exist, show `st.info("No products added yet.")`
   - Visually flag products where `expiry_date < date.today()` with a warning icon or coloured badge
   - "Toggle In Use" button per product calls `manager.toggle_active(id)` and reruns
5. **Edit Product tab**
   - If `st.session_state.edit_id` is set, pre-populate the form with current values
   - Same form fields as Add Product
   - Save button calls `manager.update_product(...)`, clears `edit_id`, shows `st.success`
   - Cancel button clears `edit_id` and reruns
   - If no `edit_id`, show `st.info("Select a product to edit from My Products.")`
6. **Delete confirmation** — use `st.warning` + confirm button pattern before calling `delete_product`

**Relevant Context**
- Streamlit reruns the entire `app.py` on every user interaction — all mutable state must
  live in `st.session_state`, not module-level variables
- `st.rerun()` forces an immediate re-render after a mutation
- Wrap every `manager.*` call in a `try/except SkincareAppError` block and surface the
  message via `st.error(str(e))`

**Status:** [ ] pending

---

### Sub-Task 8 — Unit Tests

**Intent**
Write pytest tests that cover all business logic paths. Tests must not depend on Streamlit,
a running server, or the real `data/products.json` file.

**Expected Outcomes**
- `pytest` passes with zero failures and zero warnings
- All validator edge cases are covered
- All seven `ProductManager` methods have at least one happy-path and one error-path test
- Storage round-trip test confirms serialisation fidelity for all field types

**Todo List**
1. **`tests/test_validators.py`**
   - `test_validate_name_empty` — empty string raises `InvalidFieldError`
   - `test_validate_name_whitespace_only` — whitespace-only raises `InvalidFieldError`
   - `test_validate_name_too_long` — 101-char name raises `InvalidFieldError`
   - `test_validate_name_duplicate` — matching existing name raises `DuplicateProductError`
   - `test_validate_name_duplicate_case_insensitive` — different casing still raises
   - `test_validate_name_edit_excludes_self` — same name allowed when `exclude_id` matches
   - `test_validate_description_too_long` — 301-char description raises `InvalidFieldError`
   - `test_validate_expiry_date_past` — yesterday's date raises `InvalidFieldError`
   - `test_validate_expiry_date_today` — today's date passes
   - `test_validate_expiry_date_none` — None passes and returns None
   - `test_validate_enum_field_invalid` — bad value raises `InvalidFieldError`
   - `test_validate_enum_field_valid` — valid value returns enum member

2. **`tests/test_product_manager.py`**
   - Fixture: `manager(tmp_path)` — creates a `ProductManager` pointing at a temp JSON file
   - `test_add_product_success` — adds product and returns it with correct fields
   - `test_add_product_duplicate_name` — raises `DuplicateProductError`
   - `test_get_all_products_empty` — returns empty list initially
   - `test_get_product_by_id_not_found` — raises `ProductNotFoundError`
   - `test_update_product_success` — mutated fields reflected in returned product
   - `test_update_product_not_found` — raises `ProductNotFoundError`
   - `test_delete_product_success` — product no longer in list after delete
   - `test_delete_product_not_found` — raises `ProductNotFoundError`
   - `test_toggle_active` — flips is_active and back again
   - `test_filter_by_category` — returns only products matching category
   - `test_filter_by_is_active` — returns only active/inactive products
   - `test_filter_no_matches` — returns empty list when nothing matches
   - `test_persistence` — after adding a product, a new `ProductManager` from the same path
     loads it back correctly

3. **`tests/test_storage.py`**
   - `test_load_missing_file` — returns empty list when file absent
   - `test_save_and_load_roundtrip` — all field types survive a save/load cycle
   - `test_load_corrupt_json` — returns empty list, does not raise

**Relevant Context**
- Use `pytest.fixture` with `tmp_path` for all tests that touch the file system
- Use `pytest.raises(ExceptionClass)` for all exception-path tests

**Status:** [ ] pending

---

## Data Flow

```
User Input (Streamlit form)
        |
        v
  app.py (UI layer)
  - reads enum values for selectboxes
  - calls manager method with raw values
        |
        v
  ProductManager (business logic)
  - calls validators
  - mutates self._products
  - calls storage.save_products
        |
        v
  storage.py (persistence)
  - serialises to JSON
  - writes data/products.json
```

On startup:
```
app.py init
  -> ProductManager.__init__
    -> storage.load_products
      -> reads data/products.json (or returns [] if absent)
    -> self._products populated
  -> stored in st.session_state.manager
```

---

## Validation Strategy

- All validation is **fail-fast**: the first failing rule raises an exception.
- Validators are **pure functions** in `validators.py` — no side effects.
- `ProductManager` calls validators before any mutation to the product list.
- The UI catches `SkincareAppError` and displays the message; it never inspects field-level
  error detail (no per-field inline error state needed for this scope).

---

## Exception Handling Strategy

| Layer | Raises | Catches |
|---|---|---|
| `validators.py` | `InvalidFieldError`, `DuplicateProductError` | Nothing |
| `product_manager.py` | `ProductNotFoundError` | Nothing |
| `app.py` | Nothing | `SkincareAppError` → `st.error(str(e))` |
| `storage.py` | Nothing | `JSONDecodeError` → returns `[]` |
| `tests/` | Nothing | `pytest.raises(SpecificException)` |

---

## Implementation Sequence

Sub-tasks must be completed in this order due to dependencies:

```
1. Project Scaffold
       |
       v
2. Enums and Data Model
       |
       v
3. Custom Exceptions
       |
       v
4. Validators  ──────────────────────────┐
       |                                  |
       v                                  |
5. Storage Layer                          |
       |                                  |
       v                                  |
6. ProductManager (uses 2, 3, 4, 5)  <───┘
       |
       v
7. Streamlit UI (uses 2, 3, 6)
       |
       v
8. Unit Tests (tests 4, 5, 6)
```
